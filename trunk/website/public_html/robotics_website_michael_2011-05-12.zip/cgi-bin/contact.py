#!/usr/bin/env python3.2
#
# CGI script for contact form
# Sunday, May 07 2011
# Written by Michael Lee.

import cgi
import cgitb
import time
import smtplib
import os

cgitb.enable()

### Create instance of form ###
form = cgi.FieldStorage()

### Set data. ###
if type(form.getvalue('name')) == str:
    name = form.getvalue('name')
else:
    name = "[Anonymous]"
    
if type(form.getvalue('email')) == str:
    email = form.getvalue('email')
else:
    email = "[None provided]"

if type(form.getvalue('subject')) == str:
    subject = form.getvalue('subject')
else:
    subject = "[No subject]"

if type(form.getvalue('message')) == str:
    message = form.getvalue('message')
else:
    message = "[No Message]"

about = form.getvalue('about')
    
time = time.strftime("%Y-%m-%d %H:%M:%S (%A)")



### Find out critical info ###
#logpath = "/home/deflect/logs/contact.txt"
path = "/home/deflect/__private__/email_passes.txt"
file = open(path, "r")
temp = file.read()
file.close()
temp = temp.split("\n")

# Why monkeys?  Because I was watching the Wizard of Oz.
monkey = temp[0].split(" ")[0]
monkeypass = " ".join(temp[0].split(" ")[1:])

recipient = temp[1]
host = temp[2]


### Create dump ###
list_of_params = []
for param in os.environ.keys():
    list_of_params.append(param)

spacer = len(max(list_of_params, key=len)) + 1
temp = []

for param in list_of_params:
    temp.append(param)
    for i in range(spacer - len(param)):
        temp.append(" ")
    temp.append(":")
    temp.append(os.environ[param])
    temp.append("\n")

dump = "".join(temp)


email_template = "From: Feedback <{0}>\n" \
                 "To: Admin <{1}>\n" \
                 "Subject: Feedback ({2}) \n" \
                 "\n"
email_header = email_template.format(monkey, recipient, about)

message_template = "TIME:    {0}\n" \
                   "NAME:    {1}\n" \
                   "EMAIL:   {2}\n" \
                   "SUBJECT: {3}\n" \
                   "\n" \
                   "MESSAGE:\n" \
                   "{4}\n" \
                   "\n" \
                   "INFO DUMP (bested viewed in monospace): \n"\
                   "{5}"
message = message_template.format(time, name, email, subject, message, dump)


tosend = email_header + message
log = message+ "\n\n~~~~~~~~\n\n"



#temp = open(logpath, "a")
#temp.write(log)
#temp.close()


smtpObj = smtplib.SMTP(host)
smtpObj.login(monkey.replace("@", "+"), monkeypass)
smtpObj.sendmail(monkey, recipient, tosend)

print("Content-Type: text/html")
print("Location: /feedback.html\n\n")



