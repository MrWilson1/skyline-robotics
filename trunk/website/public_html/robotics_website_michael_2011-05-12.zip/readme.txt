This folder < /resources/logomotion/ > contained various PDF resources 
which were removed from this ZIP file due to size constraints.

Visit the actual website to investigate them.
